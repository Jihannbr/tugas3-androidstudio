package com.example.tugas3;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivty extends AppCompatActivity {
    RadioGroup radioGroup;
    RadioButton selectedRadioButton;
    Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //layout instance
        buttonSubmit = findViewById(R.id.btnSubmit);
        radioGroup = findViewById(R.id.radioGroup);

        /*
        Submit Button
         */
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedRadioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                String yourVote = selectedRadioButton.getText().toString();
                CheckBox cb1, cb2, cb3, cb4;
                cb1 = findViewById(R.id.cb1);
                cb2 = findViewById(R.id.cb2);
                cb3 = findViewById(R.id.cb3);
                cb4 = findViewById(R.id.cb4);
                String checkBoxChoices = " ";

                if (cb1.isChecked()) {
                    checkBoxChoices += cb1.getText().toString() + "\tYES";
                }
                else {
                    checkBoxChoices += cb1.getText().toString() + "\tNO";
                }
                if (cb2.isChecked()) {
                    checkBoxChoices += cb2.getText().toString() + "\tYES\n";
                }
                else{
                    checkBoxChoices += cb2.getText().toString() + "\tNO\n";
                }
                if (cb3.isChecked()) {
                    checkBoxChoices += cb3.getText().toString() + "\tYES\n";
                }
                else{
                    checkBoxChoices += cb3.getText().toString() + "\tNO\n";
                }
                if (cb4.isChecked()) {
                    checkBoxChoices += cb4.getText().toString() + "\tYES\n";
                }
                else{
                    checkBoxChoices += cb4.getText().toString() + "\tNO\n";
                }
                //display it as toast to the user
                Toast.makeText(MainActivty.this, "Selected Radio Button is:" + yourVote+"\n\n"+checkBoxChoices, Toast.LENGTH_LONG).show();
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        String vote = "";
        boolean checked = ((RadioButton) view).isChecked();
        if (checked) {
            int id = view.getId();
            if (id == R.id.rb1) {
                vote = ((RadioButton) view).getText().toString();
            } else if (id == R.id.rb2) {
                vote = ((RadioButton) view).getText().toString();
            } else if (id == R.id.rb3) {
                vote = ((RadioButton) view).getText().toString();
            } else if (id == R.id.rb4) {
                vote = ((RadioButton) view).getText().toString();
            }
        }
        Toast.makeText(MainActivty.this, "Selected Radio Button is: " + vote, Toast.LENGTH_SHORT).show();
    }

    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        String vote = "";
        boolean checked = ((CheckBox) view).isChecked();
        if (checked) {
            int id = view.getId();
            if (id == R.id.cb1) {
                vote = ((CheckBox) view).getText().toString();
            } else if (id == R.id.cb2) {
                vote = ((CheckBox) view).getText().toString();
            } else if (id == R.id.cb3) {
                vote = ((CheckBox) view).getText().toString();
            }
        }
        Toast.makeText(MainActivty.this, "Checkbox Button selected is: " + vote, Toast.LENGTH_SHORT).show();
    }
}